package com.mahesh.basedprogram;

public class AgeIsNotWithInTheRangeException {
	public String toString()
    {
         return ("Age is not between 15 and 21. please Retype the Age");
    }
}


